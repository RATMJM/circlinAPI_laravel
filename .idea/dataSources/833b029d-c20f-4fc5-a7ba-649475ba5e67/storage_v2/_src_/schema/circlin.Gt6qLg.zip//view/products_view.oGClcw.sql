create definer = root@`%` view products_view as
select `p`.`id`                AS `id`,
       `p`.`created_at`        AS `생성일`,
       `b`.`name_ko`           AS `브랜드`,
       `pc`.`title`            AS `카테고리`,
       `p`.`code`              AS `제품코드`,
       concat(
               if(
                       isnull(`p`.`deleted_at`),
                       '',
                       '(삭제) '),
               `p`.`name_ko`)  AS `제품명`,
       `po`.`group`            AS `옵션그룹`,
       concat(
               if(
                       isnull(`p`.`deleted_at`),
                       '',
                       '(삭제) '),
               `po`.`name_ko`) AS `옵션명`,
       `p`.`price`             AS `제품원가`,
       `p`.`sale_price`        AS `제품판매가`,
       `p`.`shipping_fee`      AS `배송비`,
       `po`.`price`            AS `옵션가`,
       (`p`.`sale_price` +
        `po`.`price`)          AS `최종가격`,
       if(
               (`p`.`is_show` =
                1),
               '노출',
               '숨김')           AS `제품노출여부`,
       if(
               (`p`.`status` =
                'sale'),
               '판매중',
               '품절')           AS `제품상태`,
       if(
               (`po`.`status` =
                'sale'),
               '판매중',
               '품절')           AS `옵션상태`
from (((`circlin`.`products` `p` join `circlin`.`brands` `b` on ((
        `b`.`id` =
        `p`.`brand_id`))) join `circlin`.`product_categories` `pc` on ((
        `pc`.`id` =
        `p`.`product_category_id`)))
         left join `circlin`.`product_options` `po`
                   on (((`po`.`product_id` =
                         `p`.`id`) and
                        isnull(`po`.`deleted_at`))))
where isnull(`p`.`deleted_at`)
order by `p`.`order` desc,
         `p`.`id` desc;

-- comment on column products_view.제품원가 not supported: 정상가

-- comment on column products_view.제품판매가 not supported: 판매가

-- comment on column products_view.배송비 not supported: 배송비

