create definer = root@`%` view banners_available as
select `circlin`.`banners`.`id`          AS `id`,
       `circlin`.`banners`.`created_at`  AS `created_at`,
       `circlin`.`banners`.`updated_at`  AS `updated_at`,
       `circlin`.`banners`.`type`        AS `type`,
       `circlin`.`banners`.`sort_num`    AS `sort_num`,
       `circlin`.`banners`.`name`        AS `name`,
       `circlin`.`banners`.`description` AS `description`,
       `circlin`.`banners`.`started_at`  AS `started_at`,
       `circlin`.`banners`.`ended_at`    AS `ended_at`,
       `circlin`.`banners`.`deleted_at`  AS `deleted_at`,
       `circlin`.`banners`.`image`       AS `image`,
       `circlin`.`banners`.`link_type`   AS `link_type`,
       `circlin`.`banners`.`mission_id`  AS `mission_id`,
       `circlin`.`banners`.`feed_id`     AS `feed_id`,
       `circlin`.`banners`.`product_id`  AS `product_id`,
       `circlin`.`banners`.`notice_id`   AS `notice_id`,
       `circlin`.`banners`.`link_url`    AS `link_url`
from `circlin`.`banners`
order by `circlin`.`banners`.`type`,
         isnull(`circlin`.`banners`.`deleted_at`) desc,
         ((isnull(`circlin`.`banners`.`started_at`) or
           (`circlin`.`banners`.`started_at` <=
            now())) and
          (isnull(`circlin`.`banners`.`ended_at`) or
           (`circlin`.`banners`.`ended_at` >
            now()))) desc,
         `circlin`.`banners`.`sort_num` desc,
         `circlin`.`banners`.`ended_at` desc,
         `circlin`.`banners`.`id`;

-- comment on column banners_available.type not supported: 어디에 노출되는 광고인지 (float|shop|local)

-- comment on column banners_available.sort_num not supported: 정렬 순서 (높을수록 우선)

-- comment on column banners_available.name not supported: 배너명

-- comment on column banners_available.description not supported: 배너 상세설명

-- comment on column banners_available.started_at not supported: 배너 시작 일시

-- comment on column banners_available.ended_at not supported: 배너 종료 일시

-- comment on column banners_available.image not supported: 배너 이미지

-- comment on column banners_available.link_type not supported: 링크 형태 (mission|product|notice|url)

